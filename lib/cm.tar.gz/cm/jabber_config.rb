JABBER_SERVER = "o1host.net"
JABBER_CONFERENCE = "cirrocumulus@conference.o1host.net"
JABBER_DEFAULT_PASSWORD = "xen"
