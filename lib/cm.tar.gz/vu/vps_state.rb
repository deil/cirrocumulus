class VpsState < ActiveRecord::Base
end
