class StorageDiskHistory < ActiveRecord::Base
end
