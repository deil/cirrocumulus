require 'rubygems'
require 'daemons'

Daemons::run("vu/vu.rb")