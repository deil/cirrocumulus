require 'rubygems'
require 'daemons'

Daemons::run("monitor/monitor.rb")