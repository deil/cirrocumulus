require 'rubygems'
require 'daemons'

Daemons::run("notificator.rb")