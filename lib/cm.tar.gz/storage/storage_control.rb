require 'rubygems'
require 'daemons'

Daemons::run("storage/storage.rb")