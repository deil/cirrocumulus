require 'rubygems'
require 'daemons'

Daemons::run("api/api.rb")