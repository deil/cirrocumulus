class ApiRequest < ActiveRecord::Base
end
