class RaidCreateSaga < Saga
end