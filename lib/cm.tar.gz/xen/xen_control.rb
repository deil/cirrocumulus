require 'rubygems'
require 'daemons'

Daemons::run("xen/xen.rb")